<?php
$ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
$sock = @stream_socket_client("ssl://smtp.hostinger.com:465", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
if (!$sock) {
    die("FALLO conexion: $errstr ($errno)");
}
$read = function() use ($sock) { return fgets($sock, 515); };
$send = function(string $cmd) use ($sock) { fwrite($sock, $cmd . "\r\n"); };

$log = '';
$log .= $read(); // banner
$send('EHLO boostpatagonia.com');
while ($line = $read()) { $log .= $line; if (substr($line, 3, 1) === ' ') break; }
$send('AUTH LOGIN');
$log .= $read();
$send(base64_encode('contacto@boostpatagonia.com'));
$log .= $read();
$send(base64_encode('Fgs218732$$'));
$log .= $read();
$send('QUIT');
fclose($sock);

echo '<pre>' . htmlspecialchars($log) . '</pre>';
