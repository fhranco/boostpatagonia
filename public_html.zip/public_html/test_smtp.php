<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$ok = mail(
    'contacto@boostpatagonia.com',
    'Test directo',
    'Prueba desde servidor',
    "From: contacto@boostpatagonia.com\r\nContent-Type: text/plain; charset=UTF-8",
    '-f contacto@boostpatagonia.com'
);

echo $ok ? 'ENVIADO' : 'FALLO';
