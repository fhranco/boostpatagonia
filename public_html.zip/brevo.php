<?php
// Ruta: /home/u[XXXXX]/config/brevo.php
// NUNCA subas este archivo con la API key real a git público
define('BREVO_API_KEY', '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'); // ← reemplaza
define('BREVO_LIST_ID', 10);
